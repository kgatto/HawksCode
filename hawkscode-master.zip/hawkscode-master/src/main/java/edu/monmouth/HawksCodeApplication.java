package edu.monmouth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HawksCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(HawksCodeApplication.class, args);
	}

}
